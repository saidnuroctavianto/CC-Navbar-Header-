const menu = document.querySelector("#menu-button");
const sidebar = document.querySelector(".container");

menu.addEventListener("click", function() {
    sidebar.classList.toggle("hide");
})